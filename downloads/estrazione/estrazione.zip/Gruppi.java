import javax.swing.*;
import javax.swing.plaf.ColorUIResource;
import java.awt.*;
import java.util.Arrays;
import java.util.Random;

public class Gruppi {
    int[] elenco;

    public Gruppi(int dim) {
        elenco=new int[dim];
    }

    private void numeriCasuali(){
        Random r=new Random();
        int casuale, j=0, i=0;
        boolean presente;
        while(i<elenco.length){
            casuale=r.nextInt(20)+1;
            presente=false;
            j=0;
            while(j<i && presente==false){
                if(casuale==elenco[j]) {
                    presente=true;
                }
                j++;
            }
            if(presente==false){
                elenco[i]=casuale;
                i++;
            }
        }

    }

    private void riordinaCasuale(){
        int pos1, pos2, tmp;
        Random r=new Random();
        for(int i=0; i<100; i++){
            pos1=r.nextInt(20);
            pos2=r.nextInt(20);
            while(pos1==pos2){
                pos1=r.nextInt(20);
                pos2=r.nextInt(20);

            }
            tmp=elenco[pos1];
            elenco[pos1]= elenco[pos2];
            elenco[pos2]=tmp;
        }
    }

    public void generaGruppi(){
        numeriCasuali();
        riordinaCasuale();
    }

    public void spostaInFondo(int n){
        int pos=-1;
        boolean trovato=false;
        for(int i=0; i<elenco.length && trovato==false; i++){
            if(n==elenco[i]){
                pos=i;
                trovato=true;
            }
        }
        shift(pos);
        elenco[19]=n;
    }

    private void shift(int pos){
        for(int i=pos; i<elenco.length-1; i++){
            elenco[i]=elenco[i+1];
        }
    }

    public String[] convertiStringa(){
            String[] nomi=new String[elenco.length];
            for(int i=0; i< elenco.length; i++){
                switch(elenco[i]){
                    case(1):
                        nomi[i]="Abordi";
                        break;
                    case(2):
                        nomi[i]="Besseghini";
                        break;
                    case(3):
                        nomi[i]="Bricalli";
                        break;
                    case(4):
                        nomi[i]="Brisa";
                        break;
                    case(5):
                        nomi[i]="Calviello";
                        break;
                    case(6):
                        nomi[i]="Cecchi";
                        break;
                    case(7):
                        nomi[i]="De Gori";
                        break;
                    case(8):
                        nomi[i]="Fumagalli";
                        break;
                    case(9):
                        nomi[i]="Lamanna";
                        break;
                    case(10):
                        nomi[i]="Loukili";
                        break;
                    case(11):
                        nomi[i]="Magro";
                        break;
                    case(12):
                        nomi[i]="Mazzoni";
                        break;
                    case(13):
                        nomi[i]="Moretti E.";
                        break;
                    case(14):
                        nomi[i]="Moretti M.";
                        break;
                    case(15):
                        nomi[i]="Pasqualone";
                        break;
                    case(16):
                        nomi[i]="Pedrana";
                        break;
                    case(17):
                        nomi[i]="Ricciardini";
                        break;
                    case(18):
                        nomi[i]="Ronchi";
                        break;
                    case(19):
                        nomi[i]="Speziale";
                        break;
                    case(20):
                        nomi[i]="Varisto";
                        break;
                }
            }
            return nomi;
    }

    private void sleep(int millisecondi){
        try {
            Thread.sleep(millisecondi);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    public void stampaDrammatica(int n) {
        boolean parentesiChiusa=true;
        int x=2;
        if(n==1){
            x=1;
        }
        sleep(3000);
        for(int j=0, i=0, max=0; j<elenco.length+max; j++, i++) {
            System.out.print(elenco[i]+"  ");
            sleep(2000);
            if((i+1)%n==0 && i!=(elenco.length-1) && parentesiChiusa){
                System.out.print("  (  ");
                parentesiChiusa=false;
                sleep(2000);
            }
            if((j+1)%(n+x)==0){
                System.out.print(")\n");
                i-=x;
                max+=x;
                parentesiChiusa=true;
                sleep(2000);
            }
        }
    }

    private void modificaTextArea(JTextArea testo){
        Font f=new Font("SansSerif", Font.BOLD,20);
        testo.setFont(f);
        testo.setBackground(Color.BLACK);
        testo.setForeground(Color.WHITE);

    }

    private void modificaTextField(JTextField testo){
        Font f=new Font("SansSerif", Font.BOLD,20);
        testo.setFont(f);
        testo.setBackground(Color.BLACK);
        testo.setForeground(Color.WHITE);
        testo.setHorizontalAlignment(JTextField.CENTER);

    }

    private void modificaFrame(JFrame frame,JTextField testo1, JTextArea testo2){
        frame.setLayout(new GridLayout(2,1));
        frame.setSize(400,400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
        frame.add(testo1);
        frame.add(testo2);
    }

    private void partenzaConRitardo(int millisecondi, JTextArea testoSotto, JTextField testoSopra){
        testoSotto.setText(" ");
        testoSopra.setText(" ");
        sleep(millisecondi);
        testoSotto.setText("");
        testoSopra.setText("");
    }

    public void stampaDrammaticaConGrafica(int n) {
        JFrame frame=new JFrame();
        JTextField testoSopra =new JTextField();
        JTextArea testoSotto =new JTextArea("");
        modificaTextField(testoSopra);
        modificaTextArea(testoSotto);
        modificaFrame(frame,testoSopra, testoSotto);
        boolean parentesiChiusa=true;
        int x=2;
        if(n==1) {
            x = 1;
        }
        partenzaConRitardo(3000, testoSotto, testoSopra);
        for(int j=0, i=0, max=0; j<elenco.length+max; j++, i++) {
            testoSotto.append(elenco[i]+"  ");
            testoSopra.setText(elenco[i]+"  ");
            sleep(2000);
            if((i+1)%n==0 && i!=(elenco.length-1) && parentesiChiusa){
                testoSotto.append("  (  ");
                parentesiChiusa=false;
                sleep(2000);
            }
            if((j+1)%(n+x)==0){
                testoSotto.append(")\n");
                i-=x;
                max+=x;
                parentesiChiusa=true;
                sleep(2000);
            }
        }
        testoSopra.setText("");
    }

    public void stampaDrammaticaConGrafica(int n, String[] nomi) {
        JFrame frame=new JFrame();
        JTextField testoSopra =new JTextField();
        JTextArea testoSotto =new JTextArea("");
        modificaTextField(testoSopra);
        modificaTextArea(testoSotto);
        modificaFrame(frame,testoSopra, testoSotto);
        frame.setSize(800,400);
        boolean parentesiChiusa=true;
        int x=2;
        if(n==1) {
            x = 1;
        }
        partenzaConRitardo(3000, testoSotto, testoSopra);
        for(int j=0, i=0, max=0; j<nomi.length+max; j++, i++) {
            testoSotto.append(nomi[i]+"   ");
            testoSopra.setText(nomi[i]+"  ");
            sleep(2000);
            if((i+1)%n==0 && i!=(nomi.length-1) && parentesiChiusa){
                testoSotto.append("  (  ");
                parentesiChiusa=false;
                sleep(2000);
            }
            if((j+1)%(n+x)==0){
                testoSotto.append(")\n");
                i-=x;
                max+=x;
                parentesiChiusa=true;
                sleep(2000);
            }
        }
        testoSopra.setText("");
    }

    public String toString() {
        return "Gruppi{" + "elenco=" + Arrays.toString(elenco) + '}';
    }
}
