import javax.swing.*;
import java.awt.*;

public class Main {
    public static void main(String[] args) {
        bordoFrameNero();
        Gruppi gruppo;
        gruppo=new Gruppi(20);
        gruppo.generaGruppi();
        gruppo.spostaInFondo(6);  //sposta Cecchi
        gruppo.spostaInFondo(8);  //sposta Fumagalli
        gruppo.stampaDrammaticaConGrafica(4, gruppo.convertiStringa());
    }

    private static void bordoFrameNero(){
        UIDefaults uiDefaults = UIManager.getDefaults();
        uiDefaults.put("activeCaption", new javax.swing.plaf.ColorUIResource(Color.black));
        uiDefaults.put("activeCaptionText", new javax.swing.plaf.ColorUIResource(Color.black));
        JFrame.setDefaultLookAndFeelDecorated(true);
    }
}

